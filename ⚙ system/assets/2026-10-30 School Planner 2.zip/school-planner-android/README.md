# School Planner Android wrapper

This package wraps `www/index.html` in an Android app using Capacitor. The HTML app has been kept intact apart from adding localStorage persistence for its local/offline data.

## Build an APK

Requirements: Node.js LTS and Android Studio with an Android SDK installed.

1. Extract this ZIP.
2. Open a terminal in the extracted `school-planner-android` folder.
3. Run:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, wait for Gradle sync to finish.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the location of the generated APK. Usually it is `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- The app's local subjects, reminders, categories, events, friends list, and profile are saved in the device's WebView localStorage.
- The original HTML tries to use a special `claude.use(...)` integration for cloud accounts, shared events, profiles, and friend search. That integration is not provided by a normal APK, so those cloud/social features will not work unless they are replaced with a real backend.
- Google Fonts are loaded from the internet; the app otherwise bundles its HTML/CSS/JavaScript locally.
- This ZIP is the Android project source, not a precompiled APK. An Android SDK/Gradle build is required to produce the APK.
